if (!jQuery) {
    console.log('jquery.popupoverlay - jQuery not defined.');
}
require('./jquery.popupoverlay');